#!/bin/bash

# INTEL CONFIDENTIAL
# Copyright (2020) Intel Corporation
#
# The source code contained or described herein and all documents related to the source
# code("Material") are owned by Intel Corporation or its suppliers or licensors. Title
# to the Material remains with Intel Corporation or its suppliers and licensors. The
# Material contains trade secrets and proprietary and confidential information of Intel
# or its suppliers and licensors. The Material is protected by worldwide copyright and
# trade secret laws and treaty provisions. No part of the Material may be used, copied,
# reproduced, modified, published, uploaded, posted, transmitted, distributed, or
# disclosed in any way without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual property
# right is granted to or conferred upon you by disclosure or delivery of the Materials,
# either expressly, by implication, inducement, estoppel or otherwise. Any license under
# such intellectual property rights must be express and approved by Intel in writing.

# CLIENT_INTEL_DI_STATUS
# CLIENT_SDK_TPM_DI_STATUS
# CLIENT_SDK_DI_STATUS
export BOOTFS=/opt/fdo
cd $BOOTFS
sleep 60

docker load < fdoclient110.tar
# Run FDO to based on the platform
if [ -e $BOOTFS/SerialNo.txt -a -e $BOOTFS/CLIENT_INTEL_DI_STATUS -a `cat $BOOTFS/CLIENT_INTEL_DI_STATUS` = "**CLIENT_INTEL_DI_SUCCESSFUL**" -a ! -e $BOOTFS/DMS_Onboarding_done ]; then
    echo "Starting TO for CLIENT-INTEL..."
    docker run -i --rm --privileged --name fdo-dal-di -v /dev:/dev -v /sys/:/sys/ -v $BOOTFS:/target/boot fdoclient:1.1 sh -c \
        'jhid -d 2&>1 > /dev/null && sleep 2 && cd /target/boot/ &&  export LD_LIBRARY_PATH=/opt/Intel/iclsClient/lib && fdo_to -df /var/lib/intel/dal/applet_repository/fdo_all.dalp -ss -resale enabled && fdo_to -df /var/lib/intel/dal/applet_repository/fdo_all.dalp -ss && sync '
elif [ -e $BOOTFS/SerialNo.txt -a -e $BOOTFS/CLIENT_SDK_TPM_DI_STATUS -a `cat $BOOTFS/CLIENT_SDK_TPM_DI_STATUS` =  "**CLIENT_SDK_TPM_DI_SUCCESSFUL**" -a ! -e $BOOTFS/DMS_Onboarding_done ]; then
    echo "Starting TO for Client-SDK TPM..."
    docker run -i --privileged -v $BOOTFS:/target/boot fdoclient:1.1 /bin/bash -c 'cd /target/boot && cp /tpm-fdoout/linux-client . &&  /tpm-fdoout/linux-client 1 && /tpm-fdoout/linux-client'
    # To provide proxy information to Client-sdk, pass the command as
    # "cd /target/boot && echo -n my-proxy.com:443 > data/rv_proxy.dat && echo -n my-proxy.com:443 > data/owner_proxy.dat && /tpm-fdoout/linux-client"
elif [ -e $BOOTFS/SerialNo.txt -a -e $BOOTFS/CLIENT_SDK_DI_STATUS -a `cat $BOOTFS/CLIENT_SDK_DI_STATUS` = "**CLIENT_SDK_DI_SUCCESSFUL**" -a ! -e $BOOTFS/DMS_Onboarding_done ]; then
    echo "Starting TO for Client-SDK..."
    docker run -i --privileged -v $BOOTFS:/target/boot fdoclient:1.1 /bin/bash -c 'cd /target/boot && cp /fdoout/linux-client . && /fdoout/linux-client 1 && /fdoout/linux-client'
    # To provide proxy information to Client-sdk, pass the command as
    # "cd /target/boot && echo -n my-proxy.com:443 > data/rv_proxy.dat && echo -n my-proxy.com:443 > data/owner_proxy.dat && /fdoout/linux-client"
fi

# Check if OS_Install and DMS_onboarding has been completed
if [ -e $BOOTFS/DMS_Onboard.sh -a ! -e $BOOTFS/DMS_Onboarding_done ]; then
        echo "OS or Management agent is being  installed.."
        PROVISIONER=`cat $ROOTFS/opt/fdo/DMS_IP_ADDRESS`
        sleep 2
	export https_proxy=@@PROXY@@
	cd $BOOTFS && chmod a+x DMS_Onboard.sh && ./DMS_Onboard.sh ${PROVISIONER} 2883 `cat SerialNo.txt | sed -e "s:MSTRING=::"`
	echo "Onboarding to DMS completed successfully"
elif [ -e $BOOTFS/DMS_Onboarding_done ]; then
	exit 0
	cd $BOOTFS
        PROVISIONER=$(cat "$BOOTFS/data/manufacturer_addr.bin" | sed -e s/:8080//g | sed -e s/http/https/g)
        wget --no-check-certificate ${PROVISIONER}/profile/FDO-DI/files/route.sh
        wget --no-check-certificate ${PROVISIONER}/profile/FDO-DI/files/kubeadm-1-17-8.sh
        wget --no-check-certificate ${PROVISIONER}/profile/FDO-DI/files/config.toml
        wget --no-check-certificate ${PROVISIONER}/profile/FDO-DI/files/ca.crt
        wget --no-check-certificate ${PROVISIONER}/profile/FDO-DI/files/EC-containers.sh
        wget --no-check-certificate ${PROVISIONER}/profile/FDO-DI/files/kubeadm-flags.env
        /bin/bash route.sh
        /bin/bash kubeadm*.sh
        /bin/bash EC-containers.sh
        mkdir -p /etc/containerd/certs.d/192.168.2.33:9000
        cp ca.crt /etc/containerd/certs.d/192.168.2.33:9000/.
        cp config.toml /etc/containerd/.
	sed -i s/"#DNS="/"DNS=192.168.1.30"/g /etc/systemd/resolved.conf
        sed -i s/"#Domains="/"Domains=default.svc.managedcluster.local tanzu.local vmware-system-auth.svc.managedcluster.local"/g /etc/systemd/resolved.conf
        NAME=$(hostname)
        echo "127.0.0.1 $NAME" >> /etc/hosts
        systemctl daemon-reload
        systemctl restart systemd-resolved
        ./linux-client 1 && ./linux-client
        cp kubeadm-flags.env /var/lib/kubelet/.
        systemctl restart containerd
        systemctl restart kubelet
	echo "Onboarding to CSL completed successfully"
else
        echo "Either the Package to be installed was not selected from the WEB enterface or something else failed"
fi
systemctl disable fdo_to.service

