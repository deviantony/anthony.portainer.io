#!/bin/bash

sleep 20

set -o allexport
source /root/portainer_agent.conf
set +o allexport

docker run -d \
    -v /var/run/docker.sock:/var/run/docker.sock \
    -v /var/lib/docker/volumes:/var/lib/docker/volumes \
    -v /:/host \
    --restart always \
    -e EDGE=1 \
    -e EDGE_ID=${EDGE_ID} \
    -e EDGE_KEY=${EDGE_KEY} \
    -e EDGE_INSECURE_POLL=1 \
    --name portainer_edge_agent \
    portainer/agent:2.11.0

systemctl disable portainer_agent.service
