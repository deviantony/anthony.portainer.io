#!/bin/bash

# INTEL CONFIDENTIAL
# Copyright (2020) Intel Corporation
#
# The source code contained or described herein and all documents related to the source
# code("Material") are owned by Intel Corporation or its suppliers or licensors. Title
# to the Material remains with Intel Corporation or its suppliers and licensors. The
# Material contains trade secrets and proprietary and confidential information of Intel
# or its suppliers and licensors. The Material is protected by worldwide copyright and
# trade secret laws and treaty provisions. No part of the Material may be used, copied,
# reproduced, modified, published, uploaded, posted, transmitted, distributed, or
# disclosed in any way without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual property
# right is granted to or conferred upon you by disclosure or delivery of the Materials,
# either expressly, by implication, inducement, estoppel or otherwise. Any license under
# such intellectual property rights must be express and approved by Intel in writing.


usage()
{
  echo -e "Usage:
        ./$0 <OPTION>\n
        OPTION:
           [-i IP Address where Supply-Chain-Tools/All-In-One (AIO) is running]
           [-p Port where Supply-Chain-Tools/All-In-One (AIO) is listening]
           [-d device Serial number for device mstring]
           [-t Type of the Client source to use for DI. Valid values are CLIENT-INTEL (uses Client-Intel), CLIENT-SDK-TPM (uses Client-SDK TPM), CLIENT-SDK (uses Client-SDK). If any other value is provided, DI is tried in order: CLIENT-INTEL, CLIENT-SDK-TPM, CLIENT-SDK]"
}

parse_args()
{
  arg_count=0
  while getopts ":i:p:d:t:h" opt; do
    case $opt in
      i) IP_ADDRESS=$OPTARG
         ;;
      p) PORT=$OPTARG
         ;;
      d) DEVICE_SERIAL_NUMBER=$OPTARG
         ;;
      t) TYPE=$OPTARG
        ;;
      h|*) usage;
           exit 1
           ;;
      esac
  done

  if [ -z $IP_ADDRESS ]; then
    echo "No IP Address provided"
    arg_unset="true"
  fi
  if [ -z $PORT ]; then
    echo "No Port provided"
    arg_unset="true"
  fi
  if [ -z $DEVICE_SERIAL_NUMBER ]; then
    echo "No Device Serial Number provided,automatically adding a Randon 10 HEX Chr Serial Number"
    DEVICE_SERIAL_NUMBER="0"
  fi
  if [ -z $TYPE ]; then
    echo "No Type provided. Defaulting to sequential execution"
  fi
  if [ "$arg_unset" = "true" ]; then
    usage;
    exit 1;
  fi
  if [ -e $BOOTFS/SerialNo.txt ]; then
    DEVICE_SERIAL_NUMBER=$(cat $BOOTFS/SerialNo.txt | cut -c 9-)
  fi
}

export BOOTFS=/opt/fdo/dummy
cp /opt/fdo/SerialNo.txt $BOOTFS/.
parse_args "$@"

cd $BOOTFS
docker load < /opt/fdo/fdoclient110.tar
docker run -i --rm --privileged --name fdo-di  -v /dev:/dev -v /sys/:/sys/ -v $BOOTFS:/target/boot fdoclient:1.1 \
/usr/bin/run_fdo_di.sh http ${IP_ADDRESS} ${PORT} ${DEVICE_SERIAL_NUMBER} ${TYPE}
echo CLIENT_INTEL_DI_STATUS=`cat $BOOTFS/CLIENT_INTEL_DI_STATUS`
echo CLIENT_SDK_TPM_DI_STATUS=`cat $BOOTFS/CLIENT_SDK_TPM_DI_STATUS`
echo CLIENT_SDK_DI_STATUS=`cat $BOOTFS/CLIENT_SDK_DI_STATUS`
systemctl disable fdo_di
exit 0
