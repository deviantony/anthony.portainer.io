#!/bin/bash

# Copyright (C) 2019 Intel Corporation
# SPDX-License-Identifier: BSD-3-Clause

set -a

#this is provided while using Utility OS
source /opt/bootstrap/functions

# --- Ubuntu Packages ---
ubuntu_packages="net-tools"
ubuntu_tasksel="" # standard

PROVISION_LOG="/tmp/provisioning.log"
run "Begin provisioning process..." \
    "while (! docker ps > /dev/null ); do sleep 0.5; done" \
    ${PROVISION_LOG}

PROVISIONER=$1

# --- Get kernel parameters ---
kernel_params=$(cat /proc/cmdline)

if [[ $kernel_params == *"proxy="* ]]; then
	tmp="${kernel_params##*proxy=}"
	export param_proxy="${tmp%% *}"

	export http_proxy=${param_proxy}
	export https_proxy=${param_proxy}
	export no_proxy="localhost,127.0.0.1,${PROVISIONER}"
	export HTTP_PROXY=${param_proxy}
	export HTTPS_PROXY=${param_proxy}
	export NO_PROXY="localhost,127.0.0.1,${PROVISIONER}"
	export DOCKER_PROXY_ENV="--env http_proxy='${http_proxy}' --env https_proxy='${https_proxy}' --env no_proxy='${no_proxy}' --env HTTP_PROXY='${HTTP_PROXY}' --env HTTPS_PROXY='${HTTPS_PROXY}' --env NO_PROXY='${NO_PROXY}'"
	export INLINE_PROXY="export http_proxy='${http_proxy}'; export https_proxy='${https_proxy}'; export no_proxy='${no_proxy}'; export HTTP_PROXY='${HTTP_PROXY}'; export HTTPS_PROXY='${HTTPS_PROXY}'; export NO_PROXY='${NO_PROXY}';"
elif [ $( nc -vz ${PROVISIONER} 3128; echo $?; ) -eq 0 ] && [ $( nc -vz ${PROVISIONER} 4128; echo $?; ) -eq 0 ]; then
	PROXY_DOCKER_BIND="-v /tmp/ssl:/etc/ssl/ -v /usr/local/share/ca-certificates/EB.pem:/usr/local/share/ca-certificates/EB.crt"
    export http_proxy=http://${PROVISIONER}:3128/
	export https_proxy=http://${PROVISIONER}:4128/
	export no_proxy="localhost,127.0.0.1,${PROVISIONER}"
	export HTTP_PROXY=http://${PROVISIONER}:3128/
	export HTTPS_PROXY=http://${PROVISIONER}:4128/
	export NO_PROXY="localhost,127.0.0.1,${PROVISIONER}"
	export DOCKER_PROXY_ENV="--env http_proxy='${http_proxy}' --env https_proxy='${https_proxy}' --env no_proxy='${no_proxy}' --env HTTP_PROXY='${HTTP_PROXY}' --env HTTPS_PROXY='${HTTPS_PROXY}' --env NO_PROXY='${NO_PROXY}' ${PROXY_DOCKER_BIND}"
	export INLINE_PROXY="export http_proxy='${http_proxy}'; export https_proxy='${https_proxy}'; export no_proxy='${no_proxy}'; export HTTP_PROXY='${HTTP_PROXY}'; export HTTPS_PROXY='${HTTPS_PROXY}'; export NO_PROXY='${NO_PROXY}'; if [ ! -f /usr/local/share/ca-certificates/EB.crt ]; then if (! which wget > /dev/null ); then apt update && apt -y install wget; fi; wget -O - http://${PROVISIONER}/squid-cert/CA.pem > /usr/local/share/ca-certificates/EB.crt && update-ca-certificates; fi;"
    wget -O - http://${PROVISIONER}/squid-cert/CA.pem > /usr/local/share/ca-certificates/EB.pem
    update-ca-certificates
elif [ $( nc -vz ${PROVISIONER} 3128; echo $?; ) -eq 0 ]; then
	export http_proxy=http://${PROVISIONER}:3128/
	export https_proxy=http://${PROVISIONER}:3128/
	export no_proxy="localhost,127.0.0.1,${PROVISIONER}"
	export HTTP_PROXY=http://${PROVISIONER}:3128/
	export HTTPS_PROXY=http://${PROVISIONER}:3128/
	export NO_PROXY="localhost,127.0.0.1,${PROVISIONER}"
	export DOCKER_PROXY_ENV="--env http_proxy='${http_proxy}' --env https_proxy='${https_proxy}' --env no_proxy='${no_proxy}' --env HTTP_PROXY='${HTTP_PROXY}' --env HTTPS_PROXY='${HTTPS_PROXY}' --env NO_PROXY='${NO_PROXY}'"
	export INLINE_PROXY="export http_proxy='${http_proxy}'; export https_proxy='${https_proxy}'; export no_proxy='${no_proxy}'; export HTTP_PROXY='${HTTP_PROXY}'; export HTTPS_PROXY='${HTTPS_PROXY}'; export NO_PROXY='${NO_PROXY}';"
fi

if [[ $kernel_params == *"proxysocks="* ]]; then
	tmp="${kernel_params##*proxysocks=}"
	param_proxysocks="${tmp%% *}"

	export FTP_PROXY=${param_proxysocks}

	tmp_socks=$(echo ${param_proxysocks} | sed "s#http://##g" | sed "s#https://##g" | sed "s#/##g")
	export SSH_PROXY_CMD="-o ProxyCommand='nc -x ${tmp_socks} %h %p'"
fi

if [[ $kernel_params == *"httppath="* ]]; then
	tmp="${kernel_params##*httppath=}"
	export param_httppath="${tmp%% *}"
fi

if [[ $kernel_params == *"parttype="* ]]; then
	tmp="${kernel_params##*parttype=}"
	export param_parttype="${tmp%% *}"
elif [ -d /sys/firmware/efi ]; then
	export param_parttype="efi"
else
	export param_parttype="msdos"
fi

if [[ $kernel_params == *"bootstrap="* ]]; then
	tmp="${kernel_params##*bootstrap=}"
	export param_bootstrap="${tmp%% *}"
	export param_bootstrapurl=$(echo $param_bootstrap | sed "s#/$(basename $param_bootstrap)\$##g")
fi

if [[ $kernel_params == *"basebranch="* ]]; then
	tmp="${kernel_params##*basebranch=}"
	export param_basebranch="${tmp%% *}"
fi

if [[ $kernel_params == *"token="* ]]; then
	tmp="${kernel_params##*token=}"
	export param_token="${tmp%% *}"
fi

if [[ $kernel_params == *"agent="* ]]; then
	tmp="${kernel_params##*agent=}"
	export param_agent="${tmp%% *}"
else
	export param_agent="master"
fi

if [[ $kernel_params == *"kernparam="* ]]; then
	tmp="${kernel_params##*kernparam=}"
	temp_param_kernparam="${tmp%% *}"
	export param_kernparam=$(echo ${temp_param_kernparam} | sed 's/#/ /g' | sed 's/:/=/g')
fi

if [[ $kernel_params == *"ubuntuversion="* ]]; then
	tmp="${kernel_params##*ubuntuversion=}"
	export param_ubuntuversion="${tmp%% *}"
else
	export param_ubuntuversion="cosmic"
fi

# The following is bandaid for Disco Dingo
if [ $param_ubuntuversion = "disco" ]; then
	export DOCKER_UBUNTU_RELEASE="cosmic"
else
	export DOCKER_UBUNTU_RELEASE=$param_ubuntuversion
fi

if [[ $kernel_params == *"arch="* ]]; then
	tmp="${kernel_params##*arch=}"
	export param_arch="${tmp%% *}"
else
	export param_arch="amd64"
fi

if [[ $kernel_params == *"kernelversion="* ]]; then
	tmp="${kernel_params##*kernelversion=}"
	export param_kernelversion="${tmp%% *}"
else
	export param_kernelversion="linux-image-generic"
fi

if [[ $kernel_params == *"insecurereg="* ]]; then
	tmp="${kernel_params##*insecurereg=}"
	export param_insecurereg="${tmp%% *}"
fi

if [[ $kernel_params == *"username="* ]]; then
	tmp="${kernel_params##*username=}"
	export param_username="${tmp%% *}"
else
	export param_username="sys-admin"
fi

if [[ $kernel_params == *"password="* ]]; then
	tmp="${kernel_params##*password=}"
	export param_password="${tmp%% *}"
else
	export param_password="password"
fi

if [[ $kernel_params == *"debug="* ]]; then
	tmp="${kernel_params##*debug=}"
	export param_debug="${tmp%% *}"
	export debug="${tmp%% *}"
fi

if [[ $kernel_params == *"release="* ]]; then
	tmp="${kernel_params##*release=}"
	export param_release="${tmp%% *}"
else
	export param_release='dev'
fi

if [[ $param_release == 'prod' ]]; then
	export kernel_params="$param_kernparam" # ipv6.disable=1
else
	export kernel_params="$param_kernparam"
fi

if [[ $kernel_params == *"mirror="* ]]; then
    tmp="${kernel_params##*mirror=}"
    export param_mirror="${tmp%% *}"
elif wget -q --method=HEAD http://${PROVISIONER}${param_httppath}/build/dists/${param_ubuntuversion}/InRelease; then
    export param_mirror="http://${PROVISIONER}${param_httppath}/build"
elif wget -q --method=HEAD http://${PROVISIONER}${param_httppath}/distro/dists/${param_ubuntuversion}/InRelease; then
    export param_mirror="http://${PROVISIONER}${param_httppath}/distro"
fi
if [ ! -z "${param_mirror}" ]; then
    export PKG_REPO_LIST=""
    if wget -q --method=HEAD http://${PROVISIONER}${param_httppath}/build/dists/${param_ubuntuversion}/main/binary-${param_arch}/Release; then
        export PKG_REPO_LIST="${PKG_REPO_LIST} main"
    fi
    if wget -q --method=HEAD http://${PROVISIONER}${param_httppath}/build/dists/${param_ubuntuversion}/restricted/binary-${param_arch}/Release; then
        export PKG_REPO_LIST="${PKG_REPO_LIST} restricted"
    fi
    if wget -q --method=HEAD http://${PROVISIONER}${param_httppath}/build/dists/${param_ubuntuversion}/universe/binary-${param_arch}/Release; then
        export PKG_REPO_LIST="${PKG_REPO_LIST} universe"
    fi
    if wget -q --method=HEAD http://${PROVISIONER}${param_httppath}/build/dists/${param_ubuntuversion}/multiverse/binary-${param_arch}/Release; then
        export PKG_REPO_LIST="${PKG_REPO_LIST} multiverse"
    fi
    export PKG_REPO_SEC_LIST=""
    if wget -q --method=HEAD http://${PROVISIONER}${param_httppath}/build/dists/${param_ubuntuversion}-security/main/binary-${param_arch}/Release; then
        export PKG_REPO_SEC_LIST="${PKG_REPO_SEC_LIST} main"
    fi
    if wget -q --method=HEAD http://${PROVISIONER}${param_httppath}/build/dists/${param_ubuntuversion}-security/restricted/binary-${param_arch}/Release; then
        export PKG_REPO_SEC_LIST="${PKG_REPO_SEC_LIST} restricted"
    fi
    if wget -q --method=HEAD http://${PROVISIONER}${param_httppath}/build/dists/${param_ubuntuversion}-security/universe/binary-${param_arch}/Release; then
        export PKG_REPO_SEC_LIST="${PKG_REPO_SEC_LIST} universe"
    fi
    if wget -q --method=HEAD http://${PROVISIONER}${param_httppath}/build/dists/${param_ubuntuversion}-security/multiverse/binary-${param_arch}/Release; then
        export PKG_REPO_SEC_LIST="${PKG_REPO_SEC_LIST} multiverse"
    fi
fi

# --- Get free memory
export freemem=$(grep MemTotal /proc/meminfo | awk '{print $2}')

# --- Detect HDD ---
if [ -d /sys/block/nvme[0-9]n[0-9] ]; then
	export DRIVE=$(echo /dev/$(ls -l /sys/block/nvme* | grep -v usb | head -n1 | sed 's/^.*\(nvme[a-z0-1]\+\).*$/\1/'))
	if [[ $param_parttype == 'efi' ]]; then
		export EFI_PARTITION=${DRIVE}p1
		export BOOT_PARTITION=${DRIVE}p2
		export SWAP_PARTITION=${DRIVE}p3
		export ROOT_PARTITION=${DRIVE}p4
	else
		export BOOT_PARTITION=${DRIVE}p1
		export SWAP_PARTITION=${DRIVE}p2
		export ROOT_PARTITION=${DRIVE}p3
	fi
elif [ -d /sys/block/[vsh]da ]; then
	export DRIVE=$(echo /dev/$(ls -l /sys/block/[vsh]da | grep -v usb | head -n1 | sed 's/^.*\([vsh]d[a-z]\+\).*$/\1/'))
	if [[ $param_parttype == 'efi' ]]; then
		export EFI_PARTITION=${DRIVE}1
		export BOOT_PARTITION=${DRIVE}2
		export SWAP_PARTITION=${DRIVE}3
		export ROOT_PARTITION=${DRIVE}4
	else
		export BOOT_PARTITION=${DRIVE}1
		export SWAP_PARTITION=${DRIVE}2
		export ROOT_PARTITION=${DRIVE}3
	fi
elif [ -d /sys/block/mmcblk[0-9] ]; then
	export DRIVE=$(echo /dev/$(ls -l /sys/block/mmcblk[0-9] | grep -v usb | head -n1 | sed 's/^.*\(mmcblk[0-9]\+\).*$/\1/'))
	if [[ $param_parttype == 'efi' ]]; then
		export EFI_PARTITION=${DRIVE}p1
		export BOOT_PARTITION=${DRIVE}p2
		export SWAP_PARTITION=${DRIVE}p3
		export ROOT_PARTITION=${DRIVE}p4
	else
		export BOOT_PARTITION=${DRIVE}p1
		export SWAP_PARTITION=${DRIVE}p2
		export ROOT_PARTITION=${DRIVE}p3
	fi
else
	echo "No supported drives found!" 2>&1 | tee -a /dev/console
	sleep 300
	reboot
fi

export BOOTFS=/target/boot
export ROOTFS=/target/root
mkdir -p $BOOTFS
mkdir -p $ROOTFS

echo "" 2>&1 | tee -a /dev/console
echo "" 2>&1 | tee -a /dev/console
echo "Installing on ${DRIVE}" 2>&1 | tee -a /dev/console
echo "" 2>&1 | tee -a /dev/console
echo "" 2>&1 | tee -a /dev/console


# --- Create file systems ---
run "Mounting boot partition on drive ${DRIVE}" \
    "mkdir -p $BOOTFS && \
    mount ${BOOT_PARTITION} $BOOTFS" \
    ${PROVISION_LOG}

if [[ $param_parttype == 'efi' ]]; then
    export EFIFS=$BOOTFS/efi
    mkdir -p $EFIFS
    run "Mounting efi boot partition on drive ${DRIVE}" \
        "mkdir -p $EFIFS && \
        mount ${EFI_PARTITION} $EFIFS && cp $BOOTFS/SerialNo.txt $EFIFS/ " \
        ${PROVISION_LOG}
fi

# --- Create ROOT file system ---
run "Mounting root file system" \
    " mount ${ROOT_PARTITION} $ROOTFS " \
    ${PROVISION_LOG}


# --- check if we need to add memory ---
if [ $freemem -lt 6291456 ]; then
    fallocate -l 2G $ROOTFS/swap
    chmod 600 $ROOTFS/swap
    mkswap $ROOTFS/swap
    swapon $ROOTFS/swap
fi

# --- check if we need to move tmp folder ---
if [ $freemem -lt 6291456 ]; then
    mkdir -p $ROOTFS/tmp
    export TMP=$ROOTFS/tmp
else
    export TMP=/tmp
fi
export PROVISION_LOG="$TMP/provisioning.log"

if [ $(wget http://${PROVISIONER}:5557/v2/_catalog -O-) ] 2>/dev/null; then
    export REGISTRY_MIRROR="--registry-mirror=http://${PROVISIONER}:5557"
elif [ $(wget http://${PROVISIONER}:5000/v2/_catalog -O-) ] 2>/dev/null; then
    export REGISTRY_MIRROR="--registry-mirror=http://${PROVISIONER}:5000"
fi

# -- Configure Image database ---
run "Configuring Image Database" \
    "mkdir -p $ROOTFS/tmp/docker && \
    chmod 777 $ROOTFS/tmp && \
    killall dockerd && sleep 2 && \
    /usr/local/bin/dockerd ${REGISTRY_MIRROR} --data-root=$ROOTFS/tmp/docker > /dev/null 2>&1 &" \
    "$TMP/provisioning.log"

sleep 5

#while ( docker ps > /dev/null ); do sleep 0.5; done
while (! docker ps > /dev/null ); do sleep 0.5; done
export CONSOLE_OUTPUT="/dev/console"

run "Begin fdo process..." \
    "sleep 0.5" \
    "$TMP/provisioning.log"

#TODO need to add retry loop in the FDO_TO Steps
if [ -e $BOOTFS/SerialNo.txt -a -e $BOOTFS/CLIENT_INTEL_DI_STATUS -a `cat $BOOTFS/CLIENT_INTEL_DI_STATUS` = "**CLIENT_INTEL_DI_SUCCESSFUL**" ]; then
	run "Begin FDO-TO On this Device..." \
	"docker load < $BOOTFS/fdoclient110.tar && \
    	docker run -i --rm --privileged --name fdo-dal-di -v /dev:/dev -v /sys/:/sys/ -v $BOOTFS:/target/boot fdoclient:1.1 sh -c \
        'jhid -d 2&>1 > /dev/null && export LD_LIBRARY_PATH=/opt/Intel/iclsClient/lib && \
	cd /target/boot && fdo_to -df /var/cache/dal/applet_repository/fdo_all.dalp && sync ' " \
	"$TMP/provisioning.log"
elif [ -e $BOOTFS/SerialNo.txt -a -e $BOOTFS/CLIENT_SDK_TPM_DI_STATUS -a `cat $BOOTFS/CLIENT_SDK_TPM_DI_STATUS` = "**CLIENT_SDK_TPM_DI_SUCCESSFUL**" ]; then
	run "Starting TO for Client-SDK TPM..." \
	"docker load < $BOOTFS/fdoclient110.tar && \
	docker run -i --privileged -v $BOOTFS:/target/boot fdoclient:1.1 /bin/bash -c 'cd /target/boot && /tpm-fdoout/linux-client' " \
	"$TMP/provisioning.log"
    # To provide proxy information to Client-sdk, pass the command as
    # "cd /target/boot && echo -n my-proxy.com:443 > data/rv_proxy.dat && echo -n my-proxy.com:443 > data/owner_proxy.dat && /tpm-fdoout/linux-client"
elif [ -e $BOOTFS/SerialNo.txt -a -e $BOOTFS/CLIENT_SDK_DI_STATUS -a `cat $BOOTFS/CLIENT_SDK_DI_STATUS` = "**CLIENT_SDK_DI_SUCCESSFUL**" ]; then
	run "Performing FDO-TO on this device" \
    	"docker load < $BOOTFS/fdoclient110.tar && \
    	docker run -i --privileged -v $BOOTFS:/target/boot fdoclient:1.1 /bin/bash -c 'cd /target/boot && /fdoout/linux-client' && sleep 5 " \
	"$TMP/provisioning.log"
    # To provide proxy information to Client-sdk, pass the command as
    # "cd /target/boot && echo -n my-proxy.com:443 > data/rv_proxy.dat && echo -n my-proxy.com:443 > data/owner_proxy.dat && /fdoout/linux-client"
fi

if [ -e $BOOTFS/OS_Install.sh ]; then
	echo "OS is being  installed.."
	sleep 2  &&  cd $BOOTFS && chmod a+x OS_Install.sh && ./OS_Install.sh ${PROVISIONER} 
else
	run "Either the Package to be installed was not selected from the WEB enterface or something else failed. will drop into a debug shell, try debug with Utilityos" \
   	" Sleep 10 "
	"$TMP/provisioning.log"
fi

